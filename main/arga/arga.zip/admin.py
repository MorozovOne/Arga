from django.contrib import admin
from arga.models import Audio_store

admin.site.register(Audio_store)